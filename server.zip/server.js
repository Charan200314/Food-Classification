const express = require('express');
const multer = require('multer');
const path = require('path');
const db = require('./db');
const fs = require('fs');

const app = express();
const port = 4000;

// Serve static files from the "public" directory
app.use(express.static(path.join(__dirname, 'public')));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Set up multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    const filename = Date.now() + path.extname(file.originalname);
    cb(null, filename);
  },
});

const upload = multer({ storage: storage });

// API endpoint to save the image and its prediction
app.post('/save', upload.single('image'), (req, res) => {
  const { category } = req.body;
  const imagePath = path.join('C:/Users/ramya/Desktop/Food Task/uploads', req.file.filename);

  const query = 'INSERT INTO food_predictions (category, image_path) VALUES (?, ?)';

  // Save the prediction and image data into the database
  db.query(query, [category, imagePath], (err, result) => {
    if (err) {
      console.error('Error inserting data into the database: ', err);
      return res.status(500).json({ error: 'Database error' });
    }
    console.log('Data inserted successfully');
    return res.status(200).json({ message: 'Prediction saved successfully' });
  });
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
